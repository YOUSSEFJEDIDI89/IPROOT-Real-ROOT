package com.iprootx.co;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ربط بطاقة التفعيل بأنيميشن النبض
        View activateCard = findViewById(R.id.btnActivate);
        Animation pulse = AnimationUtils.loadAnimation(this, R.anim.pulse);
        activateCard.startAnimation(pulse);

        activateCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // محاكاة تفعيل النواة وربطها بالمكتبات
                Toast.makeText(MainActivity.this, "جاري استدعاء libiproot_v64.so...", Toast.LENGTH_SHORT).show();
                v.clearAnimation(); // وقف النبض عند التفعيل
                v.setBackgroundResource(R.drawable.info_card_bg); // تغيير الشكل كأن التفعيل تم
            }
        });
    }
}
