package com.iprootx.manager.animation;
import android.view.animation.Animation;
import android.view.View;

public class PulseManager {
    public static void startPulse(View view) {
        // كود برمجي حقيقي سيتم تحويله لـ DEX لاحقاً
    }
}
