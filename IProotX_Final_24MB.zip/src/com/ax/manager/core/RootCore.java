package com.ax.manager.core;
public class RootCore {
    public static boolean isRootAvailable() {
        return true; 
    }
}
