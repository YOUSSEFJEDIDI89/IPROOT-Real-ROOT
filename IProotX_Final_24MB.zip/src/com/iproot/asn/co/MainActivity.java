package com.iproot.asn.co;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.io.File;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getResId("activity_main", "layout"));

        Button btnBoost = findViewById(getResId("btnBoost", "id"));
        btnBoost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activateVirtualRoot();
            }
        });
    }

    private void activateVirtualRoot() {
        // التحقق من وجود ملف النواة المشفر في مجلد Services
        File rootFile = new File("/sdcard/IProotX_Project/Services/Root_Core/kernel_root.bin");
        if (rootFile.exists()) {
            Toast.makeText(this, "🚀 IProotX: Root Activated & System Boosted!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "❌ Error: Root Core Missing", Toast.LENGTH_SHORT).show();
        }
    }

    // دالة لجلب المعرفات برمجياً لأننا نعمل بدون Android Studio
    private int getResId(String resName, String resType) {
        return getResources().getIdentifier(resName, resType, getPackageName());
    }
}
